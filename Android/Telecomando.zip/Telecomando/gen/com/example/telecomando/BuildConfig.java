/** Automatically generated file. DO NOT MODIFY */
package com.example.telecomando;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}